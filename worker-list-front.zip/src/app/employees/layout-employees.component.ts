﻿import {Component} from '@angular/core';

@Component({templateUrl: 'layout-employees.component.html'})
export class LayoutEmployeesComponent {
}
