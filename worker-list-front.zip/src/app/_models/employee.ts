export class Employee {
    id: string;
    gender:string;
    firstName: string;
    middleName: string;
    lastName: string;    
    phone:number;
    position:string;
    dob:Date;
    salary:number;
    addinfo:string;
    dtcreate:Date;    
}
